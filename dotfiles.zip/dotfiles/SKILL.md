---
name: dotfiles
description: "Complete dotfiles repository management for ~/.dotfiles (github.com/alexfazio/dotfiles). This skill should be used when the user asks to check dotfiles sync status, edit any dotfile configuration (aerospace, ghostty, wezterm, yazi, nvim, zsh), run health checks on symlinks or launchd agents, add new application configs, troubleshoot sync failures, manage secrets, or perform any dotfiles maintenance. Triggers on requests like 'check my dotfiles', 'edit my ghostty config', 'add tmux to dotfiles', 'why did sync fail', 'is launchd running', 'scan for secrets', or 'dfs'."
---

# Dotfiles Management

This skill provides comprehensive management for the dotfiles repository at `~/.dotfiles`, enabling monitoring, editing, health checks, adding new configs, sync management, and secret protection.

## Repository Overview

**Location:** `~/.dotfiles/`
**Remote:** https://github.com/alexfazio/dotfiles
**Architecture:** Symlink-based (configs in `~/.dotfiles/` → symlinked to `~/.config/*` and `~/.zshrc`)

### Core Components

| Component | Purpose |
|-----------|---------|
| `install.sh` | New machine setup (creates symlinks, installs Homebrew packages, sets up auto-sync) |
| `rollback.sh` | Restore configs from backup |
| `scripts/auto-sync.sh` | Automated sync with secret scanning |
| `scripts/sync-status.sh` | Health monitoring (`dfs` alias) |
| `Brewfile` | Homebrew packages (auto-regenerated on sync) |

### Managed Applications

| Application | Dotfiles Path | Symlink Target |
|-------------|---------------|----------------|
| AeroSpace | `aerospace/aerospace.toml` | `~/.config/aerospace/aerospace.toml` |
| Ghostty | `ghostty/config` | `~/.config/ghostty/config` |
| WezTerm | `wezterm/wezterm.lua` | `~/.config/wezterm/wezterm.lua` |
| Yazi | `yazi/*.toml` | `~/.config/yazi/*.toml` |
| Neovim | `nvim/*` | `~/.config/nvim/*` |
| Zsh | `zsh/.zshrc` | `~/.zshrc` |

## Quick Commands

### Check Sync Status
```bash
# Full status (or use alias: dfs)
~/.dotfiles/scripts/sync-status.sh
```

### Trigger Manual Sync
```bash
~/.dotfiles/scripts/auto-sync.sh
```

### Run Health Check
```bash
~/.claude/skills/dotfiles/scripts/health-check.sh
```

### Scan for Secrets
```bash
cd ~/.dotfiles && gitleaks detect --source . --verbose
```

## Workflows

### 1. Monitoring Sync Status

To check if dotfiles are syncing correctly:

1. Run `dfs` or `~/.dotfiles/scripts/sync-status.sh`
2. Check the status output:
   - **OK** - Last sync succeeded
   - **ERROR** - Last sync failed (check message)
   - **STALE** - No sync in >24 hours
3. If stale or error, check logs: `cat ~/.dotfiles/.sync.log | tail -50`

### 2. Editing Dotfiles

To edit any dotfile configuration:

1. Read the current config using the Read tool with the **dotfiles path** (not the symlink target)
2. Make changes using the Edit tool
3. Changes will auto-sync within 1 hour, or trigger manual sync

**Important:** Always edit files in `~/.dotfiles/`, not in `~/.config/`

**Paths for editing:**
- AeroSpace: `~/.dotfiles/aerospace/aerospace.toml`
- Ghostty: `~/.dotfiles/ghostty/config`
- WezTerm: `~/.dotfiles/wezterm/wezterm.lua`
- Yazi: `~/.dotfiles/yazi/yazi.toml`, `keymap.toml`, `package.toml`
- Neovim: `~/.dotfiles/nvim/init.lua`, `~/.dotfiles/nvim/lua/`
- Zsh: `~/.dotfiles/zsh/.zshrc`

### 3. Health Checks

To verify the dotfiles system is healthy, run the bundled health check script:

```bash
~/.claude/skills/dotfiles/scripts/health-check.sh
```

This verifies:
- All symlinks are valid and pointing to correct targets
- launchd agent is loaded and running
- Pre-commit hooks are installed
- Gitleaks is available
- No pending changes older than 24 hours

### 4. Adding New Application Configs

To add a new application's configuration, follow the workflow in `references/adding-configs.md`:

1. Move config from `~/.config/newapp/` to `~/.dotfiles/newapp/`
2. Create symlink back to original location
3. Update `install.sh` to create the symlink on new machines
4. Commit or wait for auto-sync

### 5. Troubleshooting Sync Failures

When sync fails, consult `references/troubleshooting.md` for common issues:

1. **Secrets detected** - Remove the secret, add pattern to `.gitignore`
2. **Push failed** - Check network, verify git remote
3. **Pre-commit failed** - Run `pre-commit run --all-files` manually
4. **Launchd not running** - Reload the agent

### 6. Secret Protection

The dotfiles repository has three layers of secret protection:

1. **Pre-commit hooks** with gitleaks scan every commit
2. **Comprehensive .gitignore** blocks 30+ sensitive patterns
3. **Secrets template** - Real keys go in `~/.secrets.env` (gitignored)

To add a new API key:
1. Add to `~/.secrets.env` (the actual value)
2. Add placeholder to `~/.dotfiles/secrets.env.template`
3. Add pattern to `.gitignore` if needed

## Reference Documentation

For detailed information, consult the reference files:

- **`references/structure.md`** - Complete symlink mapping, file structure, launchd config
- **`references/troubleshooting.md`** - Common issues, error messages, fixes
- **`references/adding-configs.md`** - Step-by-step workflow for adding new apps

## Key Files Quick Reference

| File | Purpose |
|------|---------|
| `~/.dotfiles/.last-sync` | Health status file (ok\|error\|timestamp\|message) |
| `~/.dotfiles/.sync.log` | Detailed sync log |
| `~/.dotfiles/.gitignore` | Secret patterns (30+ rules) |
| `~/.dotfiles/.gitleaks.toml` | False positive allowlist |
| `~/.dotfiles/.pre-commit-config.yaml` | Pre-commit hook config |
| `~/Library/LaunchAgents/com.dotfiles.autosync.plist` | Hourly sync agent |
| `/tmp/dotfiles-sync.stdout.log` | launchd stdout |
| `/tmp/dotfiles-sync.stderr.log` | launchd stderr |

## Zsh Integration

The `~/.dotfiles/zsh/.zshrc` includes:

### `cc` Wrapper Function
Custom flags for Claude Code:
- `-dsp` → `--dangerously-skip-permissions`
- `-mo` → `--model opus`
- `-ms` → `--model sonnet`
- `-mh` → `--model haiku`
- `-glm` → `--settings ~/.claude/zai-settings.json` (GLM 4.7 via Z.AI)
- `@project` → Opens in `~/Documents/GitHub/<project>`

### `dfs` Alias
Quick sync status check: `alias dfs="~/.dotfiles/scripts/sync-status.sh"`

### Focus Reporting Fix
Disables Ghostty focus reporting to prevent escape sequences in Claude Code.

## Important Notes

1. **Always edit files in `~/.dotfiles/`**, not the symlink targets in `~/.config/`
2. **Changes auto-sync hourly** - no manual commits needed for routine changes
3. **Secrets detected = commit blocked** - intentional safety feature
4. **Backup exists** after first install at `~/.dotfiles-backup-*`
5. **Brewfile auto-regenerates** on every sync to capture new packages
