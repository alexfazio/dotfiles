#!/bin/bash
# =============================================================================
# health-check.sh - Comprehensive dotfiles health verification
# =============================================================================
# Checks:
#   1. All symlinks are valid and pointing to correct targets
#   2. launchd agent is loaded and running
#   3. Pre-commit hooks are installed
#   4. Gitleaks is available
#   5. No pending changes older than 24 hours
#   6. Git remote is accessible
#   7. Secret protection layers are in place
# =============================================================================

set -euo pipefail

DOTFILES_DIR="$HOME/.dotfiles"
PLIST_PATH="$HOME/Library/LaunchAgents/com.dotfiles.autosync.plist"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Counters
PASS=0
FAIL=0
WARN=0

# =============================================================================
# HELPERS
# =============================================================================

check_pass() {
    echo -e "  ${GREEN}✓${NC} $1"
    ((PASS++))
}

check_fail() {
    echo -e "  ${RED}✗${NC} $1"
    ((FAIL++))
}

check_warn() {
    echo -e "  ${YELLOW}!${NC} $1"
    ((WARN++))
}

section() {
    echo -e "\n${BLUE}=== $1 ===${NC}"
}

# =============================================================================
# SYMLINK CHECKS
# =============================================================================

check_symlinks() {
    section "Symlink Verification"

    # Define expected symlinks: target -> source
    declare -A symlinks=(
        ["$HOME/.config/aerospace/aerospace.toml"]="$DOTFILES_DIR/aerospace/aerospace.toml"
        ["$HOME/.config/ghostty/config"]="$DOTFILES_DIR/ghostty/config"
        ["$HOME/.config/wezterm/wezterm.lua"]="$DOTFILES_DIR/wezterm/wezterm.lua"
        ["$HOME/.config/yazi/yazi.toml"]="$DOTFILES_DIR/yazi/yazi.toml"
        ["$HOME/.config/yazi/keymap.toml"]="$DOTFILES_DIR/yazi/keymap.toml"
        ["$HOME/.config/nvim/init.lua"]="$DOTFILES_DIR/nvim/init.lua"
        ["$HOME/.zshrc"]="$DOTFILES_DIR/zsh/.zshrc"
    )

    for target in "${!symlinks[@]}"; do
        expected="${symlinks[$target]}"

        if [[ -L "$target" ]]; then
            actual=$(readlink "$target")
            if [[ "$actual" == "$expected" ]]; then
                check_pass "$(basename "$target") → correct"
            else
                check_fail "$(basename "$target") → wrong target ($actual)"
            fi
        elif [[ -e "$target" ]]; then
            check_fail "$(basename "$target") is a regular file (should be symlink)"
        else
            check_fail "$(basename "$target") missing"
        fi
    done
}

# =============================================================================
# LAUNCHD CHECKS
# =============================================================================

check_launchd() {
    section "Launchd Agent"

    # Check plist exists
    if [[ -f "$PLIST_PATH" ]]; then
        check_pass "Plist file exists"
    else
        check_fail "Plist file missing at $PLIST_PATH"
        return
    fi

    # Check plist syntax
    if plutil -lint "$PLIST_PATH" &>/dev/null; then
        check_pass "Plist syntax valid"
    else
        check_fail "Plist syntax invalid"
    fi

    # Check if loaded
    if launchctl list 2>/dev/null | grep -q "dotfiles"; then
        check_pass "Agent loaded"
    else
        check_fail "Agent not loaded (run: launchctl load $PLIST_PATH)"
    fi
}

# =============================================================================
# PRE-COMMIT CHECKS
# =============================================================================

check_precommit() {
    section "Pre-commit Hooks"

    # Check pre-commit installed
    if command -v pre-commit &>/dev/null; then
        check_pass "pre-commit command available"
    else
        check_fail "pre-commit not installed (run: brew install pre-commit)"
        return
    fi

    # Check hooks installed in repo
    if [[ -f "$DOTFILES_DIR/.git/hooks/pre-commit" ]]; then
        check_pass "Hooks installed in repository"
    else
        check_warn "Hooks not installed (run: cd ~/.dotfiles && pre-commit install)"
    fi

    # Check config exists
    if [[ -f "$DOTFILES_DIR/.pre-commit-config.yaml" ]]; then
        check_pass "Pre-commit config exists"
    else
        check_fail "Pre-commit config missing"
    fi
}

# =============================================================================
# GITLEAKS CHECKS
# =============================================================================

check_gitleaks() {
    section "Secret Protection"

    # Check gitleaks installed
    if command -v gitleaks &>/dev/null; then
        check_pass "gitleaks command available"
    else
        check_fail "gitleaks not installed (run: brew install gitleaks)"
        return
    fi

    # Check .gitignore exists and has patterns
    if [[ -f "$DOTFILES_DIR/.gitignore" ]]; then
        local pattern_count
        pattern_count=$(grep -v '^#' "$DOTFILES_DIR/.gitignore" | grep -v '^$' | wc -l | tr -d ' ')
        if [[ $pattern_count -ge 20 ]]; then
            check_pass ".gitignore has $pattern_count patterns"
        else
            check_warn ".gitignore only has $pattern_count patterns (expected 20+)"
        fi
    else
        check_fail ".gitignore missing"
    fi

    # Check .gitleaks.toml exists
    if [[ -f "$DOTFILES_DIR/.gitleaks.toml" ]]; then
        check_pass "Gitleaks allowlist config exists"
    else
        check_warn "Gitleaks allowlist config missing"
    fi

    # Quick scan (staged files only, fast)
    echo -e "  ${BLUE}→${NC} Running quick gitleaks scan..."
    if cd "$DOTFILES_DIR" && gitleaks detect --source . --no-git 2>/dev/null; then
        check_pass "No secrets detected"
    else
        check_fail "Potential secrets detected (run: cd ~/.dotfiles && gitleaks detect --source . --verbose)"
    fi
}

# =============================================================================
# SYNC STATUS CHECKS
# =============================================================================

check_sync_status() {
    section "Sync Status"

    local health_file="$DOTFILES_DIR/.last-sync"

    # Check health file exists
    if [[ ! -f "$health_file" ]]; then
        check_warn "No sync recorded yet"
        return
    fi

    # Parse status
    local status_line
    status_line=$(cat "$health_file")
    local status
    status=$(echo "$status_line" | cut -d'|' -f1)
    local timestamp
    timestamp=$(echo "$status_line" | cut -d'|' -f2)

    case "$status" in
        ok)
            check_pass "Last sync: OK ($timestamp)"
            ;;
        error)
            check_fail "Last sync: ERROR ($timestamp)"
            ;;
        *)
            check_warn "Unknown status: $status"
            ;;
    esac

    # Check staleness
    local last_sync
    last_sync=$(stat -f %m "$health_file" 2>/dev/null || echo 0)
    local now
    now=$(date +%s)
    local age_hours=$(( (now - last_sync) / 3600 ))

    if [[ $age_hours -lt 24 ]]; then
        check_pass "Sync is fresh ($age_hours hours ago)"
    else
        check_warn "Sync is stale ($age_hours hours ago)"
    fi

    # Check for pending changes
    cd "$DOTFILES_DIR" || return
    local changes
    changes=$(git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
    if [[ $changes -eq 0 ]]; then
        check_pass "No pending changes"
    else
        check_warn "$changes pending change(s)"
    fi
}

# =============================================================================
# GIT CHECKS
# =============================================================================

check_git() {
    section "Git Repository"

    cd "$DOTFILES_DIR" || {
        check_fail "Cannot access $DOTFILES_DIR"
        return
    }

    # Check it's a git repo
    if git rev-parse --git-dir &>/dev/null; then
        check_pass "Valid git repository"
    else
        check_fail "Not a git repository"
        return
    fi

    # Check remote configured
    local remote
    remote=$(git remote get-url origin 2>/dev/null || echo "")
    if [[ -n "$remote" ]]; then
        check_pass "Remote: $remote"
    else
        check_fail "No remote configured"
    fi

    # Check branch
    local branch
    branch=$(git branch --show-current 2>/dev/null || echo "")
    if [[ "$branch" == "main" ]]; then
        check_pass "On main branch"
    elif [[ -n "$branch" ]]; then
        check_warn "On branch: $branch (expected: main)"
    else
        check_fail "Detached HEAD state"
    fi
}

# =============================================================================
# MAIN
# =============================================================================

main() {
    echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║      Dotfiles Health Check             ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"

    check_symlinks
    check_launchd
    check_precommit
    check_gitleaks
    check_sync_status
    check_git

    # Summary
    section "Summary"
    echo -e "  ${GREEN}Passed:${NC} $PASS"
    echo -e "  ${YELLOW}Warnings:${NC} $WARN"
    echo -e "  ${RED}Failed:${NC} $FAIL"

    if [[ $FAIL -gt 0 ]]; then
        echo -e "\n${RED}Health check failed. See issues above.${NC}"
        exit 1
    elif [[ $WARN -gt 0 ]]; then
        echo -e "\n${YELLOW}Health check passed with warnings.${NC}"
        exit 0
    else
        echo -e "\n${GREEN}All checks passed!${NC}"
        exit 0
    fi
}

main "$@"
