# Dotfiles Troubleshooting Guide

Common issues, error messages, and their solutions.

## Sync Issues

### Sync Not Running (Stale)

**Symptoms:**
- `dfs` shows "STALE" or "Warning: Sync is stale (>24 hours)"
- No recent entries in `~/.dotfiles/.sync.log`

**Diagnosis:**
```bash
# Check if launchd agent is loaded
launchctl list | grep dotfiles

# Check launchd logs
cat /tmp/dotfiles-sync.stdout.log
cat /tmp/dotfiles-sync.stderr.log
```

**Solutions:**

1. **Agent not loaded:**
   ```bash
   launchctl load ~/Library/LaunchAgents/com.dotfiles.autosync.plist
   ```

2. **Agent crashed/stuck:**
   ```bash
   launchctl unload ~/Library/LaunchAgents/com.dotfiles.autosync.plist
   launchctl load ~/Library/LaunchAgents/com.dotfiles.autosync.plist
   ```

3. **Plist missing:**
   ```bash
   cd ~/.dotfiles && ./install.sh --no-brew
   ```

4. **Run sync manually:**
   ```bash
   ~/.dotfiles/scripts/auto-sync.sh
   ```

### Secrets Detected (Commit Blocked)

**Symptoms:**
- `dfs` shows "ERROR: Secrets detected! Commit blocked."
- Manual sync fails with gitleaks error

**Diagnosis:**
```bash
cd ~/.dotfiles && gitleaks detect --source . --verbose
```

**Solutions:**

1. **Remove the secret from the file:**
   - Move actual secrets to `~/.secrets.env`
   - Replace with placeholder in dotfiles

2. **Add to .gitignore (if entire file should be ignored):**
   ```bash
   echo "path/to/file" >> ~/.dotfiles/.gitignore
   ```

3. **Add to .gitleaks.toml allowlist (if false positive):**
   ```toml
   # In ~/.dotfiles/.gitleaks.toml
   [allowlist]
   regexes = [
       '''your-false-positive-pattern''',
   ]
   ```

4. **Force sync (NOT RECOMMENDED - only for debugging):**
   ```bash
   ~/.dotfiles/scripts/auto-sync.sh --force
   ```

### Push Failed

**Symptoms:**
- `dfs` shows "ERROR: Push failed! Check network."
- Sync log shows git push errors

**Diagnosis:**
```bash
cd ~/.dotfiles
git status
git remote -v
git push --dry-run
```

**Solutions:**

1. **Network issue:**
   - Check internet connection
   - Wait and retry: `~/.dotfiles/scripts/auto-sync.sh`

2. **Authentication expired:**
   ```bash
   gh auth status
   gh auth login
   ```

3. **Remote conflict:**
   ```bash
   cd ~/.dotfiles
   git fetch origin
   git status
   # If behind, pull first
   git pull --rebase origin main
   ```

4. **Wrong remote:**
   ```bash
   git remote set-url origin https://github.com/alexfazio/dotfiles.git
   ```

### Pre-commit Hook Failed

**Symptoms:**
- Sync log shows "Pre-commit hooks failed!"
- Changes are unstaged after failure

**Diagnosis:**
```bash
cd ~/.dotfiles
pre-commit run --all-files
```

**Solutions:**

1. **Gitleaks failed (secret detected):**
   - See "Secrets Detected" section above

2. **Pre-commit not installed:**
   ```bash
   brew install pre-commit
   cd ~/.dotfiles && pre-commit install
   ```

3. **Hooks corrupted:**
   ```bash
   cd ~/.dotfiles
   rm -rf .git/hooks
   pre-commit install
   ```

## Symlink Issues

### Symlink Broken or Missing

**Symptoms:**
- Application doesn't see config changes
- `ls -la ~/.config/app` shows broken symlink or regular file

**Diagnosis:**
```bash
ls -la ~/.config/aerospace/aerospace.toml
ls -la ~/.config/ghostty/config
ls -la ~/.config/wezterm/wezterm.lua
ls -la ~/.config/yazi/
ls -la ~/.config/nvim/
ls -la ~/.zshrc
```

**Solutions:**

1. **Re-run install script:**
   ```bash
   cd ~/.dotfiles && ./install.sh --no-brew --no-sync
   ```

2. **Manually recreate specific symlink:**
   ```bash
   # Example for Ghostty
   rm ~/.config/ghostty/config
   ln -sf ~/.dotfiles/ghostty/config ~/.config/ghostty/config
   ```

3. **Check if target exists:**
   ```bash
   ls -la ~/.dotfiles/ghostty/config
   # If missing, restore from git
   cd ~/.dotfiles && git checkout -- ghostty/config
   ```

### Config Changes Not Taking Effect

**Symptoms:**
- Edited file but application behavior unchanged
- Edited the symlink target instead of source

**Diagnosis:**
```bash
# Check which file you edited
ls -la ~/.config/aerospace/aerospace.toml
# Should show: ~/.config/aerospace/aerospace.toml -> ~/.dotfiles/aerospace/aerospace.toml
```

**Solutions:**

1. **Always edit the dotfiles path:**
   - Edit `~/.dotfiles/aerospace/aerospace.toml`
   - NOT `~/.config/aerospace/aerospace.toml`

2. **Reload the application:**
   - AeroSpace: `aerospace reload-config`
   - Ghostty: Open new terminal
   - WezTerm: Config auto-reloads
   - Neovim: `:source $MYVIMRC` or restart
   - Zsh: `source ~/.zshrc`

## Launchd Issues

### Agent Won't Load

**Symptoms:**
- `launchctl load` returns error
- `launchctl list | grep dotfiles` shows nothing

**Diagnosis:**
```bash
# Check plist syntax
plutil ~/Library/LaunchAgents/com.dotfiles.autosync.plist

# Check permissions
ls -la ~/Library/LaunchAgents/com.dotfiles.autosync.plist
```

**Solutions:**

1. **Invalid plist:**
   ```bash
   # Regenerate from template
   sed "s|\$HOME|$HOME|g" ~/.dotfiles/scripts/com.dotfiles.autosync.plist > ~/Library/LaunchAgents/com.dotfiles.autosync.plist
   ```

2. **Wrong permissions:**
   ```bash
   chmod 644 ~/Library/LaunchAgents/com.dotfiles.autosync.plist
   ```

3. **LaunchAgents directory missing:**
   ```bash
   mkdir -p ~/Library/LaunchAgents
   ```

### Agent Running But Not Syncing

**Symptoms:**
- `launchctl list | grep dotfiles` shows agent
- But no sync activity

**Diagnosis:**
```bash
# Check recent activity
cat /tmp/dotfiles-sync.stdout.log | tail -20
cat /tmp/dotfiles-sync.stderr.log | tail -20

# Check if script exists
ls -la ~/.dotfiles/scripts/auto-sync.sh
```

**Solutions:**

1. **Script missing execute permission:**
   ```bash
   chmod +x ~/.dotfiles/scripts/auto-sync.sh
   ```

2. **PATH issue in launchd:**
   ```bash
   # Verify PATH in plist includes /opt/homebrew/bin
   grep PATH ~/Library/LaunchAgents/com.dotfiles.autosync.plist
   ```

3. **Lock file stuck:**
   ```bash
   rm /tmp/dotfiles-sync.lock
   ```

## Git Issues

### Merge Conflicts

**Symptoms:**
- Sync fails with merge conflict
- `git status` shows conflicted files

**Solutions:**

```bash
cd ~/.dotfiles
git status

# Option 1: Keep local changes
git checkout --ours <conflicted-file>
git add <conflicted-file>

# Option 2: Accept remote changes
git checkout --theirs <conflicted-file>
git add <conflicted-file>

# Option 3: Manually resolve
vim <conflicted-file>
git add <conflicted-file>

# Continue
git commit -m "Resolve merge conflict"
git push
```

### Detached HEAD

**Symptoms:**
- `git status` shows "HEAD detached"
- Commits not on main branch

**Solutions:**

```bash
cd ~/.dotfiles

# Create a branch to save work
git checkout -b temp-branch

# Switch back to main
git checkout main

# Merge if needed
git merge temp-branch

# Delete temp branch
git branch -d temp-branch
```

## Zsh Issues

### cc Command Not Found

**Symptoms:**
- `cc` returns "command not found"
- Works after `source ~/.zshrc`

**Solutions:**

1. **New terminal session needed:**
   - Open new terminal tab/window
   - Or run: `source ~/.zshrc`

2. **Symlink broken:**
   ```bash
   ls -la ~/.zshrc
   # Should point to ~/.dotfiles/zsh/.zshrc
   ```

### Tab Completion Not Working

**Symptoms:**
- `cc @<tab>` doesn't complete project names

**Solutions:**

1. **Completion system not initialized:**
   ```bash
   # Check if compinit is called
   grep compinit ~/.zshrc
   ```

2. **Rebuild completion cache:**
   ```bash
   rm -f ~/.zcompdump*
   compinit
   ```

## Recovery Procedures

### Full Rollback

If dotfiles are causing issues and you need to restore original configs:

```bash
~/.dotfiles/rollback.sh
```

This requires a backup from the initial install.

### Fresh Start

If everything is broken:

```bash
# 1. Remove broken symlinks
rm -f ~/.zshrc
rm -rf ~/.config/aerospace ~/.config/ghostty ~/.config/wezterm ~/.config/yazi ~/.config/nvim

# 2. Remove dotfiles
rm -rf ~/.dotfiles

# 3. Re-clone and install
git clone https://github.com/alexfazio/dotfiles.git ~/.dotfiles
cd ~/.dotfiles && ./install.sh
```

### Disable Auto-Sync Temporarily

```bash
launchctl unload ~/Library/LaunchAgents/com.dotfiles.autosync.plist
```

To re-enable:
```bash
launchctl load ~/Library/LaunchAgents/com.dotfiles.autosync.plist
```
