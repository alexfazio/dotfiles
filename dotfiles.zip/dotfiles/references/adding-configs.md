# Adding New Application Configs

Step-by-step workflow for adding new application configurations to the dotfiles repository.

## Overview

The dotfiles repository uses a symlink-based architecture:
1. Actual config files live in `~/.dotfiles/<app>/`
2. Symlinks in `~/.config/<app>/` point to the dotfiles location
3. Git tracks the real files, not the symlinks

## Prerequisites

Before adding a new config:
- [ ] Application is installed and configured
- [ ] Config files exist in `~/.config/<app>/` (or another location)
- [ ] Config is stable (not frequently auto-modified by the app)

## Standard Workflow

### Step 1: Identify Config Location

Determine where the application stores its configuration:

```bash
# Common locations
ls -la ~/.config/<app>/
ls -la ~/.<app>/
ls -la ~/Library/Application\ Support/<app>/
```

### Step 2: Move Config to Dotfiles

```bash
# Create directory in dotfiles
mkdir -p ~/.dotfiles/<app>

# Move config files
mv ~/.config/<app>/* ~/.dotfiles/<app>/

# Or for a single file
mv ~/.config/<app>/config ~/.dotfiles/<app>/config
```

### Step 3: Create Symlinks

```bash
# For directory contents
ln -sf ~/.dotfiles/<app>/config ~/.config/<app>/config

# For entire directory
rmdir ~/.config/<app>
ln -sf ~/.dotfiles/<app> ~/.config/<app>
```

### Step 4: Verify Application Works

Test that the application still functions with the symlinked config:

```bash
# Open the application and verify settings are preserved
```

### Step 5: Update install.sh

Add symlink creation to the install script:

```bash
# Edit ~/.dotfiles/install.sh
```

Add lines like:

```bash
# <AppName>
ln -sf "$DOTFILES_DIR/<app>/config" ~/.config/<app>/config
```

Or for multiple files:

```bash
# <AppName>
mkdir -p ~/.config/<app>
ln -sf "$DOTFILES_DIR/<app>/config" ~/.config/<app>/config
ln -sf "$DOTFILES_DIR/<app>/theme.toml" ~/.config/<app>/theme.toml
```

### Step 6: Update rollback.sh (Optional)

If rollback support is needed, add cleanup to rollback.sh:

```bash
rm -f ~/.config/<app>/config
```

### Step 7: Commit Changes

```bash
cd ~/.dotfiles
git add -A
git commit -m "Add <app> configuration"
git push
```

Or wait for auto-sync (within 1 hour).

## Examples

### Example 1: Adding Starship Prompt

**Config location:** `~/.config/starship.toml`

```bash
# Step 1: Move config
mv ~/.config/starship.toml ~/.dotfiles/starship/starship.toml

# Step 2: Create symlink
ln -sf ~/.dotfiles/starship/starship.toml ~/.config/starship.toml

# Step 3: Update install.sh - add these lines:
# Starship
ln -sf "$DOTFILES_DIR/starship/starship.toml" ~/.config/starship.toml
```

### Example 2: Adding Tmux

**Config location:** `~/.tmux.conf` (home directory, not .config)

```bash
# Step 1: Move config
mkdir -p ~/.dotfiles/tmux
mv ~/.tmux.conf ~/.dotfiles/tmux/.tmux.conf

# Step 2: Create symlink
ln -sf ~/.dotfiles/tmux/.tmux.conf ~/.tmux.conf

# Step 3: Update install.sh - add these lines:
# Tmux
ln -sf "$DOTFILES_DIR/tmux/.tmux.conf" ~/.tmux.conf
```

### Example 3: Adding Alacritty (Multiple Files)

**Config location:** `~/.config/alacritty/`

```bash
# Step 1: Move entire directory contents
mv ~/.config/alacritty ~/.dotfiles/alacritty

# Step 2: Create symlinks
mkdir -p ~/.config/alacritty
ln -sf ~/.dotfiles/alacritty/alacritty.toml ~/.config/alacritty/alacritty.toml
ln -sf ~/.dotfiles/alacritty/themes ~/.config/alacritty/themes

# Step 3: Update install.sh - add these lines:
# Alacritty
mkdir -p ~/.config/alacritty
ln -sf "$DOTFILES_DIR/alacritty/alacritty.toml" ~/.config/alacritty/alacritty.toml
ln -sf "$DOTFILES_DIR/alacritty/themes" ~/.config/alacritty/themes
```

## Special Cases

### Application in Home Directory

Some apps store config in home directory (e.g., `.tmux.conf`, `.vimrc`):

```bash
# Move to dotfiles with same name
mv ~/.<app>rc ~/.dotfiles/<app>/.<app>rc

# Symlink back to home
ln -sf ~/.dotfiles/<app>/.<app>rc ~/.<app>rc
```

### Application with Dynamic Files

If an app frequently writes to its config (cache, history):

1. Only symlink static config files
2. Leave dynamic files in original location
3. Add dynamic files to `.gitignore`

```bash
# Example: only symlink settings.toml, not history.db
ln -sf ~/.dotfiles/<app>/settings.toml ~/.config/<app>/settings.toml
# Leave ~/.config/<app>/history.db alone
```

### Application Requiring Directory Structure

Some apps need the entire directory structure preserved:

```bash
# Symlink entire directory
mv ~/.config/<app> ~/.dotfiles/<app>
ln -sf ~/.dotfiles/<app> ~/.config/<app>
```

**Caution:** This symlinks everything including cache/temp files. Consider:
- Adding patterns to `.gitignore`
- Only symlinking specific subdirectories

### XDG Base Directory Compliance

For XDG-compliant apps:

| XDG Variable | Default Location | Use Case |
|--------------|------------------|----------|
| `XDG_CONFIG_HOME` | `~/.config` | User config |
| `XDG_DATA_HOME` | `~/.local/share` | User data |
| `XDG_CACHE_HOME` | `~/.cache` | Cache (don't track) |
| `XDG_STATE_HOME` | `~/.local/state` | State (don't track) |

Only symlink from `XDG_CONFIG_HOME`. Don't track cache or state.

## Checklist Template

When adding a new application config:

- [ ] Identified config file location
- [ ] Created `~/.dotfiles/<app>/` directory
- [ ] Moved config files to dotfiles
- [ ] Created symlinks to original locations
- [ ] Verified application works correctly
- [ ] Updated `install.sh` with symlink commands
- [ ] Updated `rollback.sh` if needed
- [ ] Committed and pushed changes

## Files to Avoid

Don't add these to dotfiles:

| Pattern | Reason |
|---------|--------|
| `*.db`, `*.sqlite` | Database files (binary, machine-specific) |
| `history*`, `*_history` | Command history (personal data) |
| `cache/`, `*.cache` | Cache directories |
| `*.log` | Log files |
| `*.lock` | Lock files |
| `credentials*`, `*.key` | Secrets (use secrets.env instead) |
| `node_modules/` | Dependencies |
| `*.pyc`, `__pycache__/` | Compiled files |

If you accidentally add sensitive files, remove them and add patterns to `.gitignore`:

```bash
# Remove from git (keep local file)
git rm --cached <file>

# Add to .gitignore
echo "<pattern>" >> ~/.dotfiles/.gitignore
```

## Post-Addition Verification

After adding a new config:

1. **Run gitleaks scan:**
   ```bash
   cd ~/.dotfiles && gitleaks detect --source . --verbose
   ```

2. **Test on-demand sync:**
   ```bash
   ~/.dotfiles/scripts/auto-sync.sh
   ```

3. **Verify symlink integrity:**
   ```bash
   ~/.claude/skills/dotfiles/scripts/health-check.sh
   ```

4. **Update README.md:**
   Add the new application to the "What's Included" table.
