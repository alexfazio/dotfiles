# Dotfiles Structure Reference

Complete reference for the dotfiles repository structure, symlink mappings, and system configuration.

## Directory Structure

```
~/.dotfiles/
├── .git/                    # Git repository
├── .gitignore               # 30+ secret patterns
├── .gitleaks.toml           # Secret scanner allowlist
├── .pre-commit-config.yaml  # Pre-commit hooks (gitleaks)
├── .last-sync               # Health status: ok|error|timestamp|message
├── .sync.log                # Detailed sync history
│
├── aerospace/
│   └── aerospace.toml       # Tiling window manager config
│
├── ghostty/
│   ├── config               # Terminal emulator config
│   └── tmux-attach.sh       # Tmux integration script
│
├── wezterm/
│   └── wezterm.lua          # Terminal emulator config (Lua)
│
├── yazi/
│   ├── yazi.toml            # File manager config
│   ├── keymap.toml          # Keybindings
│   ├── package.toml         # Plugin packages
│   └── plugins/             # Installed plugins
│
├── nvim/
│   ├── init.lua             # Neovim entry point
│   ├── lazy-lock.json       # Plugin lockfile
│   ├── lazyvim.json         # LazyVim config
│   ├── stylua.toml          # Lua formatter config
│   └── lua/                 # Lua config modules
│       ├── config/          # Core config (lazy.lua, etc.)
│       └── plugins/         # Plugin configurations
│
├── zsh/
│   └── .zshrc               # Shell config (aliases, functions, PATH)
│
├── scripts/
│   ├── auto-sync.sh         # Automated sync with secret scanning
│   ├── sync-status.sh       # Health monitoring (dfs alias)
│   └── com.dotfiles.autosync.plist  # launchd agent template
│
├── Brewfile                 # Homebrew packages (auto-updated)
├── install.sh               # New machine setup
├── rollback.sh              # Restore from backup
├── secrets.env.template     # API key template
└── README.md                # Documentation
```

## Symlink Mapping

### Primary Symlinks (created by install.sh)

| Source (in ~/.dotfiles/) | Target (system location) |
|--------------------------|--------------------------|
| `aerospace/aerospace.toml` | `~/.config/aerospace/aerospace.toml` |
| `ghostty/config` | `~/.config/ghostty/config` |
| `ghostty/tmux-attach.sh` | `~/.config/ghostty/tmux-attach.sh` |
| `wezterm/wezterm.lua` | `~/.config/wezterm/wezterm.lua` |
| `yazi/yazi.toml` | `~/.config/yazi/yazi.toml` |
| `yazi/keymap.toml` | `~/.config/yazi/keymap.toml` |
| `yazi/package.toml` | `~/.config/yazi/package.toml` |
| `yazi/plugins` | `~/.config/yazi/plugins` |
| `nvim/init.lua` | `~/.config/nvim/init.lua` |
| `nvim/lazy-lock.json` | `~/.config/nvim/lazy-lock.json` |
| `nvim/lazyvim.json` | `~/.config/nvim/lazyvim.json` |
| `nvim/stylua.toml` | `~/.config/nvim/stylua.toml` |
| `nvim/lua` | `~/.config/nvim/lua` |
| `zsh/.zshrc` | `~/.zshrc` |

### Verification Command

```bash
# Check all symlinks
ls -la ~/.config/aerospace/aerospace.toml
ls -la ~/.config/ghostty/config
ls -la ~/.config/wezterm/wezterm.lua
ls -la ~/.config/yazi/
ls -la ~/.config/nvim/
ls -la ~/.zshrc
```

## launchd Agent Configuration

**Installed location:** `~/Library/LaunchAgents/com.dotfiles.autosync.plist`
**Source template:** `~/.dotfiles/scripts/com.dotfiles.autosync.plist`

### Agent Properties

| Property | Value | Description |
|----------|-------|-------------|
| Label | `com.dotfiles.autosync` | Unique identifier |
| StartInterval | `3600` | Run every hour (seconds) |
| RunAtLoad | `true` | Run immediately when loaded |
| Nice | `10` | Low priority (won't impact system) |

### Agent Commands

```bash
# Check if agent is running
launchctl list | grep dotfiles

# Reload agent
launchctl unload ~/Library/LaunchAgents/com.dotfiles.autosync.plist
launchctl load ~/Library/LaunchAgents/com.dotfiles.autosync.plist

# View logs
cat /tmp/dotfiles-sync.stdout.log
cat /tmp/dotfiles-sync.stderr.log
```

## Health Status File Format

**Location:** `~/.dotfiles/.last-sync`
**Format:** `status|timestamp|message`

### Status Values

| Status | Meaning |
|--------|---------|
| `ok` | Last sync succeeded |
| `error` | Last sync failed |
| `unknown` | File missing or malformed |

### Example Contents

```
ok|2025-12-24 12:00:00|Synced abc1234
error|2025-12-24 11:00:00|Secrets detected! Commit blocked.
```

## Secret Protection Layers

### Layer 1: .gitignore Patterns

Located at `~/.dotfiles/.gitignore`, blocks 30+ patterns:

**Environment files:**
- `*.env`, `.env.*`, `secrets.env`, `.secrets`, `.secrets.*`

**API keys and tokens:**
- `*_token`, `*_token.*`, `*.key`, `*.pem`, `api_key*`, `auth_token*`

**Credentials:**
- `credentials.json`, `credentials.yaml`, `*.credentials`, `.netrc`, `.npmrc`, `.pypirc`

**SSH keys:**
- `id_rsa`, `id_ed25519`, `id_ecdsa`, `*.ppk`

**Cloud configs:**
- `.aws/credentials`, `.aws/config`, `*.tfvars`, `*.tfstate*`

**Local overrides:**
- `*.local`, `*.local.*`, `zsh/.zshrc.local`

### Layer 2: Pre-commit Hooks

Located at `~/.dotfiles/.pre-commit-config.yaml`:

```yaml
repos:
  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.21.2
    hooks:
      - id: gitleaks
        entry: gitleaks protect --verbose --redact --staged
```

### Layer 3: Gitleaks Allowlist

Located at `~/.dotfiles/.gitleaks.toml`:

**Ignored paths:**
- `lazy-lock.json`
- `package.toml`
- `Brewfile.lock.json`

**Ignored patterns:**
- Placeholder values: `YOUR_API_KEY_HERE`, `your-api-key`, `<API_KEY>`, `REPLACE_ME`
- Hex color codes: `#[0-9a-fA-F]{6}`
- Example domains: `example.com`, `localhost`

## Zsh Configuration Details

### cc Wrapper Function

Located at `~/.dotfiles/zsh/.zshrc` lines 97-141.

**Flag expansions:**
| Flag | Expands to |
|------|------------|
| `-dsp` | `--dangerously-skip-permissions` |
| `-mo` | `--model opus` |
| `-ms` | `--model sonnet` |
| `-mh` | `--model haiku` |
| `-glm` | `--settings ~/.claude/zai-settings.json` |

**Project shortcuts:**
- `@project` → `cd ~/Documents/GitHub/project && claude`
- Example: `cc @incide` opens Claude in incide project

**Focus reporting fix:**
- `printf '\e[?1004l'` before and after claude
- Prevents Ghostty escape sequences in Claude Code

### Tab Completion

Located at `~/.dotfiles/zsh/.zshrc` lines 143-159.

Completes:
- `@project` names from `~/Documents/GitHub/`
- Flags: `-dsp`, `-mo`, `-ms`, `-mh`, `-glm`, `-r`, `-c`, `-p`

### Dotfiles Integration

Located at `~/.dotfiles/zsh/.zshrc` lines 194-206.

```bash
# Alias for quick status check
alias dfs="~/.dotfiles/scripts/sync-status.sh"

# Load secrets (gitignored)
[ -f ~/.secrets.env ] && source ~/.secrets.env

# Warn if sync is stale on shell startup
~/.dotfiles/scripts/sync-status.sh --check 2>/dev/null
```

## Backup System

### Backup Location

First install creates: `~/.dotfiles-backup-YYYYMMDD_HHMMSS/`
Location stored in: `~/.dotfiles-backup-location`

### Backup Contents

```
~/.dotfiles-backup-*/
├── aerospace/
├── ghostty/
├── wezterm/
├── yazi/
└── nvim/
```

### Rollback Command

```bash
~/.dotfiles/rollback.sh
```

This:
1. Removes symlinks and dotfiles
2. Restores original configs from backup
3. Does NOT remove the backup (manual cleanup required)
